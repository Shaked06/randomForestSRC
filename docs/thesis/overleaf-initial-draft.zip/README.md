# Initial thesis draft for Overleaf

This is an English discussion draft using a generic report layout. Author,
supervisor, degree, institution, and university formatting are deliberately
left unspecified. The requested writing plugin has not yet been identified
or connected; this draft was prepared locally.

## Upload and compile

1. In Overleaf, choose **New Project > Upload Project** and select the ZIP
   supplied alongside this directory.
2. Use `main.tex` as the main document and **pdfLaTeX** as the compiler.
3. Recompile. The project uses BibTeX; Overleaf normally runs it automatically.
4. Replace the title-page author placeholder when ready.
5. Invite the supervisor using the project's Share control when you are ready.

No external scripts, shell escape, or R installation are needed in Overleaf.
All chapter and table files are included in the ZIP. No figures are required.

## Editing and review

Each chapter is a separate file. Edit these files rather than regenerating the
whole document. Keep an Overleaf version stable while the supervisor comments.
Overleaf warns that Git pushes may displace comments and tracked changes, so
avoid automated synchronization during active review. Source:
https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration

The numerical table is generated from the six existing `results_phases.rds`
files using `../generate_preliminary_table.R`. It includes paired Monte Carlo
standard errors for the absolute difference in truth-based curve error. It
does not rerun simulations. These are ten-replication exploratory results.

The abstract and introduction are prose drafts. The remaining chapters contain
initial explanatory text and marked work still needed. Only two starting
references are included; this is not a completed literature review.

This source has not been compiled locally because no TeX engine is installed.
